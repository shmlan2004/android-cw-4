package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       final EditText x = findViewById(R.id.editTextTextPersonName);
       final EditText z = findViewById(R.id.editTextTextPersonName3);
        Button addition = findViewById(R.id.button);
        Button multiplication = findViewById(R.id.button2);
        Button DIVISION = findViewById(R.id.button3);
        Button fast = findViewById(R.id.button4);

        addition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int x1 = Integer.parseInt(x.getText().toString());
                int z1 = Integer.parseInt(z.getText().toString());
                int num = x1 + z1;


                Toast.makeText(MainActivity.this,  num + "" , Toast.LENGTH_SHORT).show();

            }
        });
       multiplication.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               int x1 = Integer.parseInt(x.getText().toString());
               int z1 = Integer.parseInt(z.getText().toString());
               int num2 = x1 * z1;


               Toast.makeText(MainActivity.this,  num2 + "" , Toast.LENGTH_SHORT).show();
           }
       });
       DIVISION.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               int x1 = Integer.parseInt(x.getText().toString());
               int z1 = Integer.parseInt(z.getText().toString());
               int num3 = x1 / z1;

               Toast.makeText(MainActivity.this,  num3 + "" , Toast.LENGTH_SHORT).show();
           }
       });
        fast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int x1 = Integer.parseInt(x.getText().toString());
                int z1 = Integer.parseInt(z.getText().toString());
                int num4 = x1 - z1;


                Toast.makeText(MainActivity.this,  num4 + "" , Toast.LENGTH_SHORT).show();

            }
        });
    }
}